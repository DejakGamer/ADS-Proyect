package Uml;

public class Mesero extends Factura {

    private int numventas;

    private String nombre;

    private int numMesa;

    public void listaVentasMesas() {
    }

    public void numVentasMesero() {
    }
}
